#include <stdio.h>    /* entrées/sorties */
#include <unistd.h>   /* primitives de base : fork, ...*/
#include <stdlib.h>   /* exit */
#include <signal.h>

#define MAX_PAUSES 10     /* nombre d'attentes maximum */

void traitant(int sig) {
	printf("Reception %d\n", sig);
}

int main(int argc, char *argv[]) {
	struct sigaction struct_sig;
	struct_sig.sa_handler = traitant;

	sigaction(SIGUSR1, &struct_sig, NULL); //SIGUSR1
	sigaction(SIGUSR2, &struct_sig, NULL); //SIGUSR2
	
    sigset_t masque; //Création de l'emsenble des signaux
    sigemptyset(&masque); 

    sigaddset(&masque, SIGINT); //Ajout de SIGINT
    sigaddset(&masque, SIGUSR1); //Ajout de SIGUSR1

    sigprocmask(SIG_SETMASK, &masque, NULL); //Masquage des signaux

    sleep(10); //attente de 10s

    kill(getpid(), SIGUSR1);
    kill(getpid(), SIGUSR1);

    sleep(5); //attente de 5s

    kill(getpid(), SIGUSR2);
    kill(getpid(), SIGUSR2);

    sigemptyset(&masque);
    sigaddset(&masque, SIGINT); //Démasquage de SIGUSR1
    sigprocmask(SIG_SETMASK, &masque, NULL); //Masquage du signal (SIGINT)

    sleep(10); //attente de 10s

    sigemptyset(&masque); //Démasquage de SIGINT

    printf("Salut\n");


}
