#include <stdio.h>    /* entrées/sorties */
#include <unistd.h>   /* primitives de base : fork, ...*/
#include <stdlib.h>   /* exit */
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#define N 10


void tester(int nb, const char *message) {
    if (nb == -1) {
        perror(message);
    }
}


int main(int argc, char **argv) {
    pid_t pidFils1, pidFils2;
    int tube_who_grep[2];
    int tube_grep_wc[2];

    pipe(tube_who_grep);
    pipe(tube_grep_wc);

    if (argc != 2) {
        perror("Usage : ./wgw nom_utilisateur\n");
    }

    switch(pidFils1 = fork()) {

        case -1 :
            perror("Erreur du fork 1\n");
            break;

        case 0 : //fils grep

            switch(pidFils2 = fork()) {
                case -1 :
                    perror("Erreur du fork 2\n");
                    break;

                case 0 : //petit fils wc
                    close(tube_who_grep[1]); //fermeture des deux canaux car inutile ici
                    close(tube_who_grep[0]);

                    close(tube_grep_wc[1]);
                    dup2(tube_grep_wc[0], 0);
                    tester(execlp("wc", "wc", "-l", NULL), "Erreur d'éxecution de wc");

                    close(tube_grep_wc[0]);
                    exit(1);
                    break;

                default : //fils grep
                    close(tube_grep_wc[0]); 
                    close(tube_who_grep[1]);

                    dup2(tube_who_grep[0], 0);
                    dup2(tube_grep_wc[1], 1);
                    tester(execlp("grep", "grep", argv[1],NULL), "Erreur d'éxecution du grep");

                    close(tube_who_grep[0]);
                    close(tube_grep_wc[1]);
                    break;
            } 
            exit(1);
            break;

        default : //père who
            close(tube_grep_wc[1]); //fermeture des deux canaux car inutile ici
            close(tube_grep_wc[0]);

            close(tube_who_grep[0]);

            dup2(tube_who_grep[1],1);
            tester(execlp("who", "who", NULL), "Erreur d'éxecution du who");

            close(tube_who_grep[1]);
            break;
    }

    return EXIT_SUCCESS;
}